//
//  TVCAnimal.swift
//  ZooApp
//
//  Created by LABMAC15 on 15/03/19.
//  Copyright © 2019 utng. All rights reserved.
//

import UIKit

class TVCAnimal: UITableViewCell {

    @IBOutlet weak var ivAnimaImage: UIImageView!
    
    
    @IBOutlet weak var ivAnimalDes: UITextView!
    @IBOutlet weak var ivAnimalName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func SetAnimal(animal:Animal){
        self.ivAnimalName.text = animal.name!
        self.ivAnimalDes.text = animal.des!
        self.ivAnimaImage.image = UIImage(named:animal.image!)
    }
        override func  setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}


//
//  Food.swift
//  FoodApp2
//
//  Created by LABMAC28 on 26/03/19.
//  Copyright © 2019 LABMAC28. All rights reserved.
//

import UIKit

class Food {
    var name: String?
    var des:String?
    var image:String?
    init (name:String,des:String,image:String) {
        self.name = name
        self.des = des
        self.image = image
    }
}

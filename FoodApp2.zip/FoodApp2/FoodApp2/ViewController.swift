//
//  ViewController.swift
//  FoodApp2
//
//  Created by LABMAC28 on 26/03/19.
//  Copyright © 2019 LABMAC28. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource{
    var listOfFoods = [Food]()
    @IBOutlet weak var cvListOfFoods: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadFoodsFromPropertyList()
        
        cvListOfFoods.delegate = self
        cvListOfFoods.dataSource = self
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int{
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listOfFoods.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt idexPath: IndexPath) -> UICollectionViewCell {
        
        let cellFood:CVCFood = collectionView.dequeueReusableCell(withReuseIdentifier: "cellFood", for: idexPath) as! CVCFood
        cellFood.setFood(food: listOfFoods[idexPath.row])
        return cellFood
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        performSegue(withIdentifier: "showDetails", sender: listOfFoods[indexPath.row])
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "showDetails" {
        if let dis = segue.destination as? VCFDetails {
            
            if let food = sender as? Food {
                dis.food = food
            }
        }
    }
}
        
        

    func loadFoodsFromPropertyList(){
        let path = Bundle.main.path(forResource: "Foods", ofType: "plist")! as String; let url = URL(fileURLWithPath: path)
        
        do{
            let data = try Data(contentsOf:url)
            let plist = try PropertyListSerialization.propertyList(from: data, options: .mutableContainers, format: nil)
            let dicArray = plist as! [[String:String]]
            for food in dicArray {
                
                
                listOfFoods.append(Food(name: food["Name"]!, des: food["Des"]!, image: food["Image"]!))
            }
        }catch{
            print("cannot read file")


          }
        }
}


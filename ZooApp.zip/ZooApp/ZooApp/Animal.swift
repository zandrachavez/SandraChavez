//
//  Animal.swift
//  ZooApp
//
//  Created by LABMAC15 on 15/03/19.
//  Copyright © 2019 utng. All rights reserved.
//

import UIKit

class Animal {
    var name:String?
    var des:String?
    var image:String?
    
    init(name:String,des:String,image:String) {
        self .name=name
        self .des=des
        self .image=image
    }

}

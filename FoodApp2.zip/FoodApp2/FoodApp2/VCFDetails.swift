//
//  VCFDetails.swift
//  FoodApp2
//
//  Created by LABMAC28 on 26/03/19.
//  Copyright © 2019 LABMAC28. All rights reserved.
//

import UIKit

class VCFDetails: UIViewController {
    
    @IBOutlet weak var iv_FoodImage: UIImageView!
    
    @IBOutlet weak var laFoodDes: UITextView!
    @IBOutlet weak var laFoodNamed: UILabel!
    var food:Food?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        laFoodNamed.text = food?.name!
        laFoodDes.text = food?.des!
        iv_FoodImage.image = UIImage(named: (food?.image)!)
        

    }

    @IBAction func buBack(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
    }
}
